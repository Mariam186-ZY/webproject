using System.Collections.Generic;

namespace EventCalendarApp.Models
{
    public class EventCalendarContext : DbContext
    {
        public EventCalendarContext(DbContextOptions<EventCalendarContext> options)
            : base(options)
        {
        }

        public ISet<Event> Events { get; set; }

        internal Task SaveChangesAsync()
        {
            throw new NotImplementedException();
        }
    }

    public class DbContextOptions<T>
    {
    }

    public class DbContext
    {
        public DbContext(DbContextOptions<EventCalendarContext> options)
        {
        }
    }
}
