using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using EventCalendar.Models;

namespace EventCalendar.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }
    public IActionResult Calendar()
{
    
    return View();
}
public IActionResult Dashboard()
{
    // Prepare static data for the dashboard
    var dashboardData = new
    {
        TotalEvents = 10,
        UpcomingEvents = 3,
        PastEvents = 7
    };

    // Pass the static data to the view
    return View(dashboardData);
}

public IActionResult UpcomingEvents()
{
    // Mock data for upcoming events
    var upcomingEvents = new List<string> { "Event 1", "Event 2", "Event 3" };
    // Pass the mock data to the view
    return View(upcomingEvents);
}

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
