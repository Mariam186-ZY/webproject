using System.Net;
using EventCalendar.Models;
using Microsoft.AspNetCore.Mvc;

namespace YourNamespace.Controllers
{
    public class EventController : Controller
    {
        // Static list to simulate a database
        private static List<Event> _events = new List<Event>();

        // GET: Events
        public ActionResult Index()
        {
            return View(_events);
        }

        // GET: Events/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = _events.FirstOrDefault(e => e.EventId == id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        private ActionResult HttpNotFound()
        {
            throw new NotImplementedException();
        }

        // GET: Events/Create
        public ActionResult Create()
        {
            return View();
        }

       
        
        // GET: Events/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = _events.FirstOrDefault(e => e.EventId == id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        // POST: Events/Edit/5
        
         // POST: Events/Create
[HttpPost]
[ValidateAntiForgeryToken]
public ActionResult Create(Event @event)
{
    if (ModelState.IsValid)
    {
        // Assuming _events is a static list of Event objects
        // You might want to generate a unique EventId for the new event
        @event.EventId = _events.Any() ? _events.Max(e => e.EventId) + 1 : 1;
        _events.Add(@event);
        return RedirectToAction("Index");
    }

    return View(@event);
}

       
        // GET: Events/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = _events.FirstOrDefault(e => e.EventId == id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        // POST: Events/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Event @event = _events.FirstOrDefault(e => e.EventId == id);
            if (@event != null)
            {
                _events.Remove(@event);
            }
            return RedirectToAction("Index");
        }
    }

    internal class HttpStatusCodeResult : ActionResult
    {
        private object badRequest;

        public HttpStatusCodeResult(object badRequest)
        {
            this.badRequest = badRequest;
        }
    }
}
